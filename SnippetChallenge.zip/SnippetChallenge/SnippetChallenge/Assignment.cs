﻿using Mentula.JSON;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnippetChallenge
{
    public class Assignment
    {
        public DateTime From { get; set; }
        public DateTime To { get; set; }
        public int Correct { get; set; }
        public int InCorrect { get; set; }
        public int Progress { get; set; }
        public int UserId { get; set; }
        public string Subject { get; set; }
        public string Domain { get; set; }
        public string LearningObjective { get; set; }

        public Assignment(Container container)
        {
            From = DateTime.Parse(container.GetString("SubmitDateTime"));
            To = From;
            Correct = container.GetInt("Correct");
            InCorrect = 1 - Correct;
            Progress = container.GetInt("Progress");
            UserId = container.GetInt("UserId");
            Subject = container.GetString("Subject");
            Domain = container.GetString("Domain");
            LearningObjective = container.GetString("LearningObjective");
        }
    }
}
