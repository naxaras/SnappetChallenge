﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using Mentula.JSON;

namespace SnippetChallenge
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            DateTime d = DateTime.Parse("2015-03-24T11:30:00");
            InitializeComponent();
            List<Assignment> Assignments = GetAssignmentsBeforeDate(d);
            CompactAssignmentList(ref Assignments);
            dataGridView1.DataSource = Assignments;
        }

        /// <summary>
        /// Gets all assignments from the same day and before the given time
        /// </summary>
        public List<Assignment> GetAssignmentsBeforeDate(DateTime date)
        {
            //Load the JSON file with assignments and put it in a container
            List<Assignment> Assignments = new List<Assignment>();
            string dir = Directory.GetCurrentDirectory();
            FileStream fs = new FileStream($@"{dir}\work.json", FileMode.Open);
            Mentula.JSON.Container c = JsonSource.DecodeStream(fs);

            //Check all assignments and add them to the list if they are on the same day and before the given time
            for (int i = 0; i < c.ChildLength; i++)
            {
                if (AssignmentIsBeforeDate(ref c, i, date))
                {
                    Assignments.Add(new Assignment(c[i]));
                }
            }
            return Assignments;
        }

        /// <summary>
        /// Checkis if an assignment is on the same day and before the given date
        /// </summary>
        public bool AssignmentIsBeforeDate(ref Mentula.JSON.Container c, int index, DateTime date)
        {
            bool isBeforeDate = false;
            DateTime assignmentDate = DateTime.Parse(c[index].GetString("SubmitDateTime"));
            if (assignmentDate < date && assignmentDate.DayOfYear == date.DayOfYear)
            {
                isBeforeDate = true;
            }
            return isBeforeDate;
        }

        /// <summary>
        /// Combine all assignments that have the same userID, Subject, Domain, and LearningObjective
        /// </summary>
        public void CompactAssignmentList(ref List<Assignment> Assignments)
        {
            for (int i = 0; i < Assignments.Count - 1; i++)
            {
                Assignment assignment1 = Assignments[i];
                for (int j = i + 1; j < Assignments.Count - 1;)
                {
                    // if 2 assignments have the same UserId, Subject, Domain, And LearningObjective
                    //combine them and remove the second one
                    //else go look further in the list
                    Assignment assignment2 = Assignments[j];
                    if (assignment1.UserId == assignment2.UserId &&
                        assignment1.Subject == assignment2.Subject &&
                        assignment1.Domain == assignment2.Domain &&
                        assignment1.LearningObjective == assignment2.LearningObjective)
                    {
                        Assignments[i].To = assignment2.From;
                        Assignments[i].Correct += assignment2.Correct;
                        Assignments[i].InCorrect += assignment2.InCorrect;
                        Assignments[i].Progress += assignment2.Progress;
                        Assignments.RemoveAt(j);
                    }
                    else
                    {
                        j++;
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
